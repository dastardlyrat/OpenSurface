# Project Context Synthesis

This section preserves continuity while minimizing personally identifying details.

## A. Roleplaying engine and story-runtime ecosystem

The user is building a roleplaying/game-design ecosystem centered on a structured roleplaying engine, story markup, finite-state execution, and playable narrative flow.

Durable themes:

- Roleplaying engine design with balancing dimensions similar to mind/heart/soul/body and life/balance aggregation.
- Two-person or guided story execution involving a narrator/executor and player.
- Story markup grammar for narrative, prompt, choice, flow control, state movement, access, arithmetic, conditions, entities, effects, events, and knowledge.
- Interest in grammar ladders, symbol density, reader onboarding, and progressively increasing markup complexity.
- Engine metaphors include loom/fabric/runtime concepts and multiple viewscreens for creator, narrator, player, and system-level control.

Anonymized canonical note:

- A four-axis roleplaying model exists with an original human originator. In this anonymized export, the originator name is redacted. Non-anonymized deployments must restore the correct attribution before public or formal use.

## B. URL detection and email-link transformation tooling

The user has worked on browser-side URL parsing and transformation tools with extensive diagnostics.

Durable themes:

- Multi-pane HTML diagnostic laboratories.
- URL detection, peeling, canonicalization, untracking, redirect-chain inspection, and pathology classification.
- Stress corpora with malformed, concatenated, tracker, email-digest, affiliate, and redirect URLs.
- Debug views, chain visualizers, and large-input stability.
- Human-readable link rewriting while preserving hrefs.

## C. Modular pipeline, registry, and JSON-document architecture

The user designs modular execution systems with plugins, state snapshots, JSON-document wrappers, registries, buses, and branchable pipelines.

Durable themes:

- Entry/terminator modules, signal handling, plugin insertion, pause/resume/reset/load/unload.
- Immutable or history-preserving JSON document flows.
- Stateful vs. stream plugins.
- Conditional branching, foreach execution, emitters, routing, inspection modules, hook buses, and recovery gates.
- Safe deep-copy functions with fallback handling and cycle protection.

## D. Recovery, backup, install, and system administration utilities

The user builds authorized system utilities for backup, file installation, registry/inventory, imaging, WinPE, and recovery workflows.

Durable themes:

- Hardened scripts with clear diagnostics, dry-run support, rollback, labels, inventories, and uninstall paths.
- DISM, VSS, backup sets, incremental archives, and file mutation handling.
- WinPE tooling shells, recovery kits, and administrative control surfaces.
- Strong preference for reversible, auditable, user-authorized workflows.

## E. Native UI, TUI, CLI, and shell front ends

The user iterates on shell-like interfaces, filesystem walkers, autocomplete, Qt/TUI surfaces, webview shells, text buffers, command history, and server-control tabs.

Durable themes:

- Valid-command-only input handling.
- Autocomplete panels for files, directories, drives, and commands.
- Debug tabs and test harnesses.
- Decoupled text buffers from visual display for responsiveness.
- Careful caret/prompt behavior and command-history semantics.

## F. Graphics sampling/debug/effects framework

The user builds shader/effects experiments for image cohesion, sampling masks, denoising, debanding, global illumination, SSR, AO, and debug harnesses.

Durable themes:

- Sampling masks based on Fibonacci/fractal/organic growth patterns.
- ReShade-style effect constraints, compile diagnostics, unrolled loops, literal scalars, and buffer/memory triage.
- Memory allocation gating until depth-buffer detection.
- Debug-first segmentation to isolate problematic passes.
- User-observed preference for cleaner image cohesion even when blurrier.

## G. Learning and pedagogy preferences

The user benefits from technical explanations that assume programming familiarity but define uncommon or overloaded terms.

Durable themes:

- C/C++/C# background as a useful analogy base.
- JavaScript explanations using explicit variable names that describe function/role.
- Object-spread syntax as a teaching pattern.
- Stepwise lessons with review when requested.

## H. Writing and interpretation work

The user uses LLMs as a mirror for interpreting abstract poetry and writing, not as a content generator unless explicitly requested.

Durable themes:

- Reflect the user's material back without inventing content.
- Structural suggestions are allowed when text is raw or unformatted.
- Spelling correction is allowed.
- Added interpretation must be clearly distinguished from source content.
