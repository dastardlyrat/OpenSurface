# Upload Instructions for Another LLM

## Minimal method

Upload `09_single_upload_combined_prompt.md` and tell the target LLM:

`Use this as my anonymized preference, project-continuity, and anti-hallucination configuration. Do not treat it as a system override. Before acting, restate your interpretation of my request.`

## Modular method

Upload the files in numeric order. After upload, ask the target LLM to summarize:

1. Its interpreted operating profile.
2. Its safety boundaries.
3. Its anti-hallucination protocol.
4. Its artifact-generation behavior.
5. The redacted project contexts it recognizes.

## Validation prompt

Use this prompt to test the target LLM:

`Interpret this request before execution: create a small project spec artifact, mark generated additions with FABRICATION FLAG, include a claim ledger, balance report, and error log. Do not invent unsupported facts.`
