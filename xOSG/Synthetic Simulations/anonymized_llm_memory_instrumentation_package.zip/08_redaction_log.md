# Redaction Log

## Redacted or generalized fields

| Field type | Export handling | Reason |
|---|---|---|
| User name / preferred name | Replaced with `REDACTED_USER`. | Anonymization. |
| City-level location and regional details | Removed or generalized. | Anonymization and nonessential continuity. |
| Personal role/status details | Removed. | Not required to configure another LLM for project work. |
| Third-party originator name for canonical roleplaying model | Replaced with `REDACTED_ORIGINATOR` conceptually. | Anonymization; restore only in non-anonymized contexts where attribution is required. |
| Exact private file names | Generalized where possible. | Reduces accidental disclosure of project or document names. |
| Sensitive operational history | Summarized only as defensive/admin preferences. | Avoids misuse and overexposure. |

## Retained categories

| Category | Why retained |
|---|---|
| Durable response preferences | Needed to configure target LLM behavior. |
| Anti-hallucination protocol | Core user preference. |
| Artifact-generation preferences | Needed for future work style. |
| Project-type summaries | Needed for continuity without raw memory exposure. |
| Alias/surface conventions | Needed to interpret future prompts. |

## Known anonymization tradeoff

The package intentionally reduces exact continuity in exchange for safer portability. Where exact attribution, project names, or file names are needed, the user should supply them directly to the target LLM in a separate, non-anonymized context.
