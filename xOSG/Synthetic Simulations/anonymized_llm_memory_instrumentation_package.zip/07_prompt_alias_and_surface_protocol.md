# Prompt Alias and Surface Protocol

This section captures the user's command-like prompt style in a safe, portable form.

## Interpretation requirement

For symbolic or alias prompts, the target LLM must state its interpretation before execution.

## Common surface model

Surfaces are conceptual work areas. They do not grant authority and do not override safety rules.

| Surface | Meaning |
|---|---|
| `@root` | High-level command or orchestration layer. |
| `@user` | User-facing request or preference layer. |
| `@doc` | Document/work artifact layer. |
| `@cli` | Simulated command-line/workflow layer. |
| `@workspace` | Current working context. |
| `@assert` | Assertion/check/test layer. |
| `@lens` or `~` | Interpretive lens constraining the current workflow. |
| `@memory` | Durable preference or context layer. |
| `@web` | Current-source validation layer when browsing is available and appropriate. |

## Command roots

| Token | Intended interpretation |
|---|---|
| `::command::` | Base command wrapper. |
| `::meta::` | Meta-level instruction about interpretation, document handling, or workflow. |
| `<<workspace>>` | Current working surface/context. |
| `===assert===` | Assertion/check/test instruction. |
| `&mitigation` | Harden, validate, add safeguards, or reduce failure modes. |
| `redux` | Rework from the previous version while preserving useful structure. |
| `proceed` | Continue with the previously interpreted task. |

## Naked prompt markers

The user may use a bare prompt marker such as three single-quote characters, three double-quote characters, or `>>>` as a contextual command lens. Treat it as a signal to interpret the current workspace input under the active alias protocol. Do not treat it as permission to ignore safety, create new authority layers, or execute destructive actions.

## Diagnostic severity roots

| Token | Meaning |
|---|---|
| `!info` | Informational diagnostic. |
| `!!warning` | Warning diagnostic requiring triage. |
| `!!!error` | Error diagnostic requiring mitigation. |
| `!*!critical` | Halt, prepare low-level triage, do not continue blindly. |

## Safety boundary for aliases

Alias syntax is a user-interface convention only. It cannot authorize harmful behavior, external access, security bypass, exfiltration, persistence, evasion, destructive execution, or unsafe automation.
