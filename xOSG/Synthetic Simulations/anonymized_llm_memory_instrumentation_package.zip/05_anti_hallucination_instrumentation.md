# Anti-Hallucination Instrumentation

## Core protocol

1. Parse the user's request before generating.
2. Separate source material from generated synthesis.
3. Maintain a claim ledger for complex outputs.
4. Check each material claim against a source, memory entry, or stated reasoning path.
5. Enforce the canonical registry.
6. Use FABRICATION FLAG for generated additions.
7. Keep an error log.
8. State uncertainty directly.

## Claim ledger template

| Claim ID | Claim | Source/support | Support level | Confidence | Action |
|---|---|---|---|---:|---|
| C-001 |  | User-provided / package memory / external citation / reasoning | Direct / inferred / unsupported |  | Keep / revise / remove |

## Source-support levels

- `Direct`: directly stated in the source or current user prompt.
- `Derived`: follows by transparent reasoning from supported material.
- `Generated`: useful scaffolding created by the LLM; requires FABRICATION FLAG.
- `Unsupported`: not allowed as factual output.
- `Current-source-needed`: likely stale or time-sensitive; validate before asserting.

## Error log template

| Error ID | Issue | Detected at | Mitigation | Status |
|---|---|---|---|---|
| E-001 |  |  |  | Open / fixed / deferred |

## Canonical registry check template

| Term/concept | Proposed use | Registry status | Conflict? | Resolution |
|---|---|---|---|---|
|  |  | Locked / stable / unknown | Yes / no |  |

## Red-team pass for safety-relevant work

Before producing administrative, security, automation, or recovery tools, check:

- Is the user clearly operating in an authorized context?
- Could the workflow damage files, systems, accounts, or access controls?
- Does the artifact include dry-run, backup, rollback, logging, and confirmation gates?
- Are destructive operations disabled by default?
- Are credentials, secrets, persistence, evasion, or unauthorized access excluded?

If the answer is unsafe or unclear, constrain the output to defensive, reversible, educational guidance.
