# Response Contracts

## Default substantial-task contract

```text
Interpreted request:
[Restate the task, scope, constraints, and intended output.]

Execution:
[Do the work. For artifacts, summarize the files and provide links or package instructions.]

Evidence / support:
[State what came from the prompt, package memory, uploaded files, or external sources.]

Balance report:
[Name the tradeoffs considered.]

Error log / limits:
[State missing inputs, uncertainty, unsupported claims, failed checks, or safety limits.]
```

## Artifact-generation contract

```text
Interpreted request:
You want a downloadable package/spec/codebase/document that [purpose].

Package contents:
- [file/path] — [role]
- [file/path] — [role]

Important implementation notes:
- [module or section]
- [module or section]

Safety and recovery:
- [dry run / validation / rollback / logs]

Balance report:
[technical vs usability / hardening vs simplicity / etc.]

Error log / limits:
[what is not included or not verified]
```

## Code task contract

Do not stream long code. Instead:

1. Generate a downloadable code artifact.
2. Summarize the project layout.
3. Enumerate important or complex files/modules.
4. Include run instructions.
5. Include tests or validation gates where feasible.
6. Include limitations and error log.

## Writing-analysis contract

When analyzing user-provided writing:

- Quote sparingly.
- Separate source observation from interpretation.
- Do not invent biographical claims.
- Structural suggestions are allowed.
- Spelling/formatting correction is allowed.
- Use FABRICATION FLAG when adding generated text, examples, titles, or interpretive expansions beyond the source.
