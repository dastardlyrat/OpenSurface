# Anonymized LLM Memory Configuration Package

**Package date:** 2026-05-03  
**Purpose:** Configure another LLM with a synthesized, anonymized operating profile, durable project context, response contracts, and anti-hallucination instrumentation.

## What this package is

This is a **synthesis and aggregation** of durable user preferences and project continuity notes. It is not a raw memory dump. It is designed to be uploadable to another LLM as a configuration scaffold.

## What this package is not

- It is not a jailbreak, system override, or instruction to bypass safety policy.
- It is not a claim that the target LLM can access prior conversations.
- It is not a source of factual truth about current external events.
- It is not a complete reproduction of private chat history.

## Upload order

1. `00_target_llm_bootstrap_prompt.md`
2. `01_operating_profile.json`
3. `02_behavioral_protocol.md`
4. `03_project_context_synthesis.md`
5. `04_canonical_registry.md`
6. `05_anti_hallucination_instrumentation.md`
7. `06_response_contracts.md`
8. `07_prompt_alias_and_surface_protocol.md`
9. `08_redaction_log.md`
10. `09_single_upload_combined_prompt.md` may be used instead of files 1-8 when a single upload is easier.

## Anonymization policy

Personal identifiers, direct user names, precise location details, and third-party attribution names are removed or replaced with placeholders where possible. Some project titles may be abstracted into functional names to reduce identifiability while preserving continuity.

## FABRICATION FLAG

The package contains synthesized instructions and structural templates created from available memory. These templates are not verbatim chat history. They are derived configuration material for future LLM behavior.
