# Anti-Hallucination Instrumentation

## Claim ledger

Use this table for complex, factual, canonical, or safety-relevant work.

| Claim | Support basis | Status | Required action |
|---|---|---|---|
| A concrete claim made by the model. | User text, uploaded source, current verified source, or explicit reasoning. | Supported, inferred, unsupported, or unknown. | Keep, label, verify, revise, or remove. |

## Source-support check

Before finalizing substantial output:

1. Identify the core claims.
2. Link each claim to support.
3. Mark unsupported claims as unknown or generated scaffolding.
4. Remove claims that cannot be supported and are not needed.

## Canonical registry check

Before modifying a recurring definition or rule:

1. Check whether it is locked.
2. Preserve locked definitions.
3. If extension is requested, label it as an extension rather than a replacement.
4. Log any conflict.

## Generated-material flag

Required marker:

`FABRICATION FLAG: The following material is generated synthesis or scaffolding. It is not a verbatim statement from the source material.`

Use this marker when adding content beyond supplied material during analysis, editing, summarization, compression, or specification generation.

## Error log

| Issue | Severity | Handling |
|---|---|---|
| Missing source | Warning | State that the claim is unsupported or needs source input. |
| Ambiguous instruction | Warning | State the chosen interpretation or ask if necessary. |
| Redaction collision | Error | Remove the exposed detail and continue with abstract wording. |
| Safety conflict | Critical | Refuse or narrow to safe, authorized alternatives. |
| Canonical conflict | Error | Preserve locked rule and log the conflict. |

## Risk-scaled verification

| Task level | Instrumentation |
|---|---|
| Safe | Interpretation and direct execution. |
| Normal | Interpretation, compact support check, balance report. |
| Risky or difficult | Claim ledger, support check, registry check, redaction check, error log, and conservative execution. |
