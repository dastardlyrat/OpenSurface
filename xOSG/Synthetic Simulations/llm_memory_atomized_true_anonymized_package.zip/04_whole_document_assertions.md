# Whole-Document Assertion Contract

Use these assertions to evaluate this package as a whole.

## Structural assertions

| Assertion | Required state |
|---|---|
| The package is synthesized, not raw history. | Pass required. |
| Personal identifiers are absent. | Pass required. |
| Precise location details are absent. | Pass required. |
| Named workstreams and private file names are absent. | Pass required. |
| Domain narratives are abstracted into atoms and intents. | Pass required. |
| Console-style shortcut and instruction-token layers are absent. | Pass required. |
| The target model is not told to override safety. | Pass required. |
| The package includes redaction, validation, and error-handling rules. | Pass required. |
| The package includes bidirectional memory-to-work and work-to-memory application rules. | Pass required. |
| The package can be uploaded as a single file or modular package. | Pass required. |

## Behavioral assertions

| Assertion | Required behavior |
|---|---|
| Interpretation precedes substantial execution. | The model states the operational reading first. |
| Unsupported claims are not treated as facts. | The model labels or omits unsupported claims. |
| Generated additions are marked. | The model uses a generated-material flag when adding scaffolding. |
| Complex outputs include instrumentation. | The model includes claim ledger, support check, registry check, and error log as needed. |
| Balance is reported for substantial work. | The model identifies relevant tradeoffs. |
| Redaction is preserved by default. | The model does not reintroduce removed specifics. |

## Failure handling

If any assertion fails, the target model should:

1. Stop treating the affected section as reliable.
2. State the failed assertion.
3. Apply the redaction rule.
4. Continue only with the sanitized remainder.
