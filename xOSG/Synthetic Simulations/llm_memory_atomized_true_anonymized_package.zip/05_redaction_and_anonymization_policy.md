# Redaction and Anonymization Policy

## Redaction goals

The goal is to preserve operating value while removing identifying or overly specific content.

## Redacted categories

| Category | Handling |
|---|---|
| Personal identity | Replace with a generic placeholder or omit. |
| Precise place references | Omit unless the active user supplies them for a current task. |
| Named workstreams | Omit from this package. |
| Private filenames | Omit from this package. |
| Domain narratives | Convert to reusable atoms and intent patterns. |
| Interface syntax | Omit from this package. |
| Raw chat history | Do not include. |
| Third-party attribution names | Omit in anonymized export. |

## Redaction method

1. Extract repeated preference or behavior pattern.
2. Convert it to an abstract atom or intent.
3. Remove names, titles, identifiers, and domain storyline.
4. Check the full package for residue.
5. Preserve a redaction log by category, not by repeating sensitive strings.

## Reintroduction rule

The target model must not reintroduce redacted specifics from this package. If exact details are needed, the user must provide them in the active session.
