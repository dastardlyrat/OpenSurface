# Upload Instructions

## Single-file method

Upload `09_single_upload_combined_prompt.md` and instruct the target model to treat it as an anonymized preference and instrumentation profile, not as a safety override.

## Modular method

Upload the numbered files in order:

1. Bootstrap.
2. Operating profile.
3. Atomic intent profile.
4. Bidirectional application rules.
5. Whole-document assertions.
6. Redaction policy.
7. Anti-hallucination instrumentation.
8. Canonical registry.
9. Response contracts.
10. Safety boundary.
11. Redaction log.

## Validation prompt for the target model

Ask the target model to summarize:

- Its interpretation-before-execution rule.
- Its redaction boundary.
- Its generated-material flag rule.
- Its claim-support process.
- Its safety boundary.
- Its error-log behavior.

The target model should not reproduce raw history or infer removed specifics.
